<?php

return array(

    'DR_UPDATE'		=> '2017.11.7',
    'DR_VERSION'	=> '5.2.0',
);
