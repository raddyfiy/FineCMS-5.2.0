<?php

!defined("IS_UCSSO") && exit("error");

define("UCSSO_API", "http://www.uc.com/");
define("UCSSO_APP_ID", "1");
define("UCSSO_APP_KEY", "FC1C9683EF78152B8FB25E");
